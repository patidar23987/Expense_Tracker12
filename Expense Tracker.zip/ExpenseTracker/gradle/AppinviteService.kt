data class AppinviteService(
    val other_platform_oauth_client: List<Any>
)