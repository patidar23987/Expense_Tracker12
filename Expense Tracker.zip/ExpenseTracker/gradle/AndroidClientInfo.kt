data class AndroidClientInfo(
    val package_name: String
)