data class ClientInfo(
    val android_client_info: AndroidClientInfo,
    val mobilesdk_app_id: String
)