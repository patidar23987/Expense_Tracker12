data class Services(
    val appinvite_service: AppinviteService
)