data class ProjectInfo(
    val project_id: String,
    val project_number: String,
    val storage_bucket: String
)