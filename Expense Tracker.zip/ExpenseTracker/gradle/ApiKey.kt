data class ApiKey(
    val current_key: String
)